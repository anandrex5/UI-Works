package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.FragmentManager;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import retrofit2.Retrofit;

public class MainActivity extends AppCompatActivity {
    Button button1,buttonn;
    private Bundle args;
    private Toolbar toolbar;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

//        toolbar =findViewById(R.id.myToolBar);
//        setSupportActionBar(toolbar);


        buttonn = findViewById(R.id.buttonn);
        buttonn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                Intent intent = new Intent(MainActivity.this, JsonRecyclerView.class);
//                Intent intent = new Intent(MainActivity.this, RetroFitModel.class);
                Intent intent = new Intent(MainActivity.this, JsonRetroFit.class);
                startActivity(intent);

            }
        });
        FragmentManager fragmentManager = getSupportFragmentManager();
        fragmentManager.beginTransaction()
                .replace(R.id.fragmentContainerView,new MainFragment()).commit();

        FragmentManager fragmentManager1 = getSupportFragmentManager();
        fragmentManager1.beginTransaction()
                .replace(R.id.abc,new MainFragment2()).commit();




    }
}

//Switch Button to Activity
//        Log.v("activity_lifestyle","OnCreate1 called");
//        button = (Button) findViewById(R.id.button);
//      button.setOnClickListener(new View.OnClickListener() {

//            @Override
//            public void onClick(View view) {
//
//
//            }
//    }

//    @Override
//    protected void onStart() {
//        super.onStart();
//        Log.v("activity_lifestyle","OnStart1 called");
//    }
//
//    @Override
//    protected void onResume() {
//        super.onResume();
//        Log.v("activity_lifestyle","OnResume1 called");
//    }
//
//    @Override
//    protected void onPause() {
//        super.onPause();
//        Log.v("activity_lifestyle","OnPause1 called");
//    }
//
//    @Override
//    protected void onStop() {
//        super.onStop();
//        Log.v("activity_lifestyle","OnStop1 called");
//    }
//
//    @Override
//    protected void onDestroy() {
//        super.onDestroy();
//        Log.v("activity_lifestyle","OnDestroy1 called");


// printLinkedList();















        //Parcelable
//        Animals obj2=new Animals();
//          obj2.setName1("Lion");
//          obj2.setFunctinalities("Hunt");
//
//          Intent intent = new Intent(MainActivity.this,ThirdActivity.class);
//          intent.putExtra("Mammals",obj2);
//          startActivity(intent);





//Serializable
//        Employees model = new Employees();
//        model.setId(755);
//        model.setName("Anand");
//
//        Intent intent= new Intent(MainActivity.this,SecondActivity.class);
//        intent.putExtra("Human", model);
//        startActivity(intent);







        //PrintAbstractionClass();

        //MultilevelInheritanceClass();
        //HierarchicalInheritanceClass();
        //SingleInheritanceClass();
        //HybridInheritanceClass();
        //PolymorphimClass();
        //OverRidingClass();
        //OverloadingClass();
        //EncapsulationClass();
        //InterafaceClass();
        //ConstructorClass();
        //DefaulConstructorClass();
        //ParameterizedConstructorClass();
        //printArrayList();
        //printArray();
        //printStringBuffer();
        //printStringBuilder();





//    private void printLinkedList() {
//
//        LinkedList<String> al = new LinkedList<String>();
//        al.add("Ravi");
//        al.add("Vijay");
//        al.add("Ravi");
//        al.add("Ajay");
//
//        Iterator<String> itr = al.iterator();
//        while (itr.hasNext()) {
//            Toast.makeText(this, "" + itr.next(), Toast.LENGTH_SHORT).show();
//        }
//    }

//    private void printStringBuilder() {
//        StringBuilder builder=new StringBuilder("Welcome");
//        builder.append("User");
//        Toast.makeText(this, ""+builder, Toast.LENGTH_SHORT).show();
//    }


//    //printStringBuffer();
//    private void printStringBuffer() {
//        StringBuffer buffer=new StringBuffer("Welcome");
//        buffer.append("User");
//        Toast.makeText(this, ""+buffer, Toast.LENGTH_SHORT).show();
//    }


//    //array
//    private void printArray() {
//
//        int[] arr = new int[3];
//        arr[0] = 5;
//        arr[1] = 6;
//        arr[2] = 10;
//
//        Toast.makeText(this, ""+ Arrays.toString(arr), Toast.LENGTH_SHORT).show();
//    }


//    //ArrayList
//    private void printArrayList() {
//        ArrayList<Integer> arr = new ArrayList<Integer>();
//        arr.add(5);
//        arr.add(9);
//        arr.add(11);
//
//        Toast.makeText(this, ""+arr, Toast.LENGTH_SHORT).show();
//
//    }


//    //Parameterized Constructor
//    private void ParameterizedConstructorClass() {
//        Main2 myObj = new Main2(5);
//        Log.v(Main2.class.getSimpleName(), "myObj" + (myObj.x));
//    }
//
//
//    public class Main2 {
//        int x;
//
//        public Main2(int y) {
//            x = y;
//        }
//
//    }
//
//
//    //Default Constructor
//    private void DefaulConstructorClass() {
//        new Demo();
//    }
//
//    class Demo {
//        public Demo() {
//            Log.v(Demo.class.getSimpleName(), "This is a no argument constructor");
//        }
//
//    }
//
//
//    //constructor
//
//    private void ConstructorClass() {
//        Hello obj = new Hello();
//        Log.v(Hello.class.getSimpleName(), "Hello Google");
//    }
//
//    public class Hello {
//        String name;
//
//        //Constructor
//        Hello() {
//            this.name = "Google.com";
//        }
//    }
//
//
//    //Interface
//    private void InterafaceClass() {
//
//        Mammals i = new Mammals();
//        i.eat();
//        i.travel();
//    }
//
//
//    //overiding
//    private void OverloadingClass() {
//        Adder adder = new Adder();
//        Toast.makeText(MainActivity.this, "" + adder.add(10, 20), Toast.LENGTH_SHORT).show();
//        Toast.makeText(this, "" + adder.add(12.3, 12.6), Toast.LENGTH_SHORT).show();
//    }
//
//    class Adder {
//        int add(int a, int b) {
//            return a + b;
//        }
//
//        double add(double a, double b) {
//            return a + b;
//        }
//    }
//
//
//    //overiding
//    private void OverRidingClass() {
//        Car b = new Audi();//upcasting
//        b.run();
//    }
//
//    class Car {
//        void run() {
//            System.out.println("running");
//        }
//    }
//
//    class Audi extends Car {
//        void run() {
//            Toast.makeText(MainActivity.this, "running safely with 200km", Toast.LENGTH_SHORT).show();
//        }
//    }
//
//
//    //polymorphism
//    private void PolymorphimClass() {
//        Animal myAnimal = new Animal();  // Create a Animal object
//        Animal myPig = new Pig();  // Create a Pig object
//        Animal myDog = new Dog();  // Create a Dog object
//        myAnimal.animalSound();
//        myPig.animalSound();
//        myDog.animalSound();
//    }
//
//    class Animal {
//        public void animalSound() {
//            Toast.makeText(MainActivity.this, "The animal makes a sound", Toast.LENGTH_SHORT).show();
//        }
//    }
//
//    class Pig extends Animal {
//        public void animalSound() {
//            Toast.makeText(MainActivity.this, "The pig says: wee wee", Toast.LENGTH_SHORT).show();
//        }
//    }
//
//    class Dog extends Animal {
//        public void animalSound() {
//            Toast.makeText(MainActivity.this, "The dog says: bow wow\"", Toast.LENGTH_SHORT).show();
//        }
//    }
//
//    class Main1 {
//    }
//
//
//    //hybrid
//    private void HybridInheritanceClass() {
//        Daughter1 obj = new Daughter1();
//        obj.show();
//    }
//
//    class GrandFather {
//        public void show() {
//            Toast.makeText(MainActivity.this, "I am grandfather.", Toast.LENGTH_SHORT).show();
//        }
//    }
//
//    //inherits GrandFather properties
//    class Father extends GrandFather {
//        public void show() {
//            Toast.makeText(MainActivity.this, "I am father.", Toast.LENGTH_SHORT).show();
//        }
//    }
//
//    //inherits Father properties
//    class Son extends Father {
//        public void show() {
//            Toast.makeText(MainActivity.this, "I am son.", Toast.LENGTH_SHORT).show();
//        }
//    }
//
//    //inherits Father properties
//    public class Daughter1 extends Father {
//        public void show() {
//            Toast.makeText(MainActivity.this, "I am a daughter.", Toast.LENGTH_SHORT).show();
//        }
//
//
//        //Hierarchical
//        private void HierarchicalInheritanceClass() {
//            Son s = new Son();
//            Daughter1 d = new Daughter1();
//        }
//
//        class Father1 {
//            String familyName;
//            String houseaddress;
//
//            Father1() {
//                familyName = "Programmer";
//                houseaddress = "Delhi";
//            }
//        }
//
//        class Son extends Father1 {
//            Son() {
//                Toast.makeText(MainActivity.this, "I am the Son", Toast.LENGTH_SHORT).show();
//                Toast.makeText(MainActivity.this, "My family name is \" + this.familyName + \" and I am from \" + this.houseaddress", Toast.LENGTH_SHORT).show();
//            }
//        }
//
//        class Daughter extends Father1 {
//            Daughter() {
//                Toast.makeText(MainActivity.this, "I am the Daughter", Toast.LENGTH_SHORT).show();
//                Toast.makeText(MainActivity.this, "My family name is \" + this.familyName + \" and I am from \" + this.houseaddress", Toast.LENGTH_SHORT).show();
//            }
//        }
//
//
//        //single inheritance
//        private void SingleInheritanceClass() {
//            Rectangle rect = new Rectangle();
//            rect.display();
//            rect.area();
//        }
//
//        class Shape {
//            public void display() {
//                Toast.makeText(MainActivity.this, "Inside display", Toast.LENGTH_SHORT).show();
//            }
//        }
//
//        class Rectangle extends Shape {
//            public void area() {
//                Toast.makeText(MainActivity.this, "Inside area", Toast.LENGTH_SHORT).show();
//            }
//        }
//
//        public class Tester {
//        }
//
//
//        //Multilevel
//        private void MultilevelInheritanceClass() {
//            Son1 s1 = new Son1();
//        }
//
//        class GrandFather {
//            GrandFather() {
//                Toast.makeText(MainActivity.this, "I am the grandfather!", Toast.LENGTH_SHORT).show();
//            }
//        }
//
//        class Father extends GrandFather {
//            String familyName;
//            String houseaddress;
//
//            Father() {
//                Toast.makeText(MainActivity.this, "I am the father! I inherit from Grandfather", Toast.LENGTH_SHORT).show();
//            }
//        }
//
//        public class Son1 extends Father {
//            Son1() {
//                Toast.makeText(MainActivity.this, "I am the son and I inherit from my father.", Toast.LENGTH_SHORT).show();
//            }
//
//
//            //Abstraction
//            private void PrintAbstractionClass() {
//                Dog d1 = new Dog();
//
//                d1.makeSound();
//                d1.eat();
//            }
//
//            abstract class Animal {
//                abstract void makeSound();
//
//                public void eat() {
//                    Toast.makeText(MainActivity.this, "Bark bark", Toast.LENGTH_SHORT).show();
//                }
//            }
//
//            class Dog extends Animal {
//
//                // provide implementation of abstract method
//                public void makeSound() {
//                    Toast.makeText(MainActivity.this, "My name is Anand", Toast.LENGTH_SHORT).show();
//                }
//            }
//
//        }
//
//    }
//}







