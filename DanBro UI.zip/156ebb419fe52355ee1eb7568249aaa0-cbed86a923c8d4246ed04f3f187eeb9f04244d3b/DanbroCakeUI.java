package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.content.DialogInterface;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;

public class DanbroCakeUI extends AppCompatActivity {

    TextView home;
    TextView work;
    TextView other;
    Button button_save;
    Boolean Item_Selected = false;
    Dialogue_message dialogue_message;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.modify_danbro_ui2);

        home= findViewById(R.id.textView_home);
        work = findViewById(R.id.textView_work);
        other = findViewById(R.id.textView_other);
        button_save = findViewById(R.id.save_button);
        Item_Selected = false;


        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                home.setTextColor(Color.WHITE);
                home.setBackgroundColor(Color.BLACK);
                Item_Selected = true;

            }
        });

        work.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                work.setTextColor(Color.WHITE);
                work.setBackgroundColor(Color.BLACK);
                Item_Selected = true;

            }
        });
        other.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                other.setTextColor(Color.WHITE);
                other.setBackgroundColor(Color.BLACK);
                Item_Selected = true;

            }
        });
        button_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(Item_Selected){
                    Toast.makeText(DanbroCakeUI.this, "Proceed", Toast.LENGTH_SHORT).show();

                }else
//                    Toast.makeText(DanbroCakeUI.this, "Please Select Any Text", Toast.LENGTH_SHORT).show();


                dialogmessage();

            }
        });
    }

    private void dialogmessage() {
//        dialogue_message = new Dialogue_message(this);
//        dialogue_message.show();


        new MaterialAlertDialogBuilder(DanbroCakeUI.this)
                .setTitle("Alert")
                .setMessage("Please Select the Text")
                .setPositiveButton("GOT IT", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                    }
                })
                .setNegativeButton("CANCEL", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                    }
                })
                .show();



    }
}

